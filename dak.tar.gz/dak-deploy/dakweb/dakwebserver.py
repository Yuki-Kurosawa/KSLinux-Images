#! /usr/bin/env python3

"""Main script to run the dakweb server and also
to provide the list_paths and path_help functions

@contact: Debian FTPMaster <ftpmaster@debian.org>
@copyright: 2014  Mark Hymers <mhy@debian.org>
@license: GNU General Public License version 2 or later
"""

import json

import bottle
from bottle import redirect

from daklib.dbconn import DBConn
from dakweb.webregister import QueryRegister


@bottle.route("/")
def root_path():
    """Returns a useless welcome message"""
    return json.dumps("Use the /list_paths path to list all available paths")


QueryRegister().register_path("/", root_path)


@bottle.route("/list_paths")
def list_paths():
    """Returns a list of available paths"""
    redirect(
        "https://ftp-team.pages.debian.net/dak/docs/generated/dakweb.html#module-dakweb"
    )


QueryRegister().register_path("/list_paths", list_paths)


# Import our other methods
from .queries import archive, binary, changelog, madison, source, suite  # noqa: F401

# Run the bottle if we're called directly
if __name__ == "__main__":
    # Set up our initial database connection
    d = DBConn()
    bottle.run()
