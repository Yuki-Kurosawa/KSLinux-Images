"""Packages' changelogs related queries

@contact: Debian FTPMaster <ftpmaster@debian.org>
@copyright: 2025  Sérgio Cipriano <cipriano@debian.org>
@license: GNU General Public License version 2 or later
"""

import json
from datetime import datetime

import bottle
from sqlalchemy import TIMESTAMP, cast, or_

from daklib.dbconn import DBChange, DBChangelog, DBConn
from dakweb.webregister import QueryRegister


@bottle.route("/changelogs")
def changelogs() -> str:
    """Legacy endpoint; prefer /v2/changelogs.

    Returns all matching rows (no pagination). Use only for backward compatibility.
    Required param: search_term.
    """

    search_term = bottle.request.query.get("search_term", "").strip()

    bottle.response.content_type = "application/json; charset=UTF-8"
    # Add advisory / deprecation style headers
    bottle.response.set_header(
        "Warning",
        '299 dakweb "/changelogs is legacy; prefer /v2/changelogs (adds pagination & filters)"',
    )
    bottle.response.set_header("X-Legacy-Endpoint", "true")
    bottle.response.set_header("X-Preferred-Endpoint", "/v2/changelogs")

    if not search_term:
        bottle.response.status = 400
        return json.dumps({"error": "Missing required query parameter: search_term"})

    s = DBConn().session()

    q = (
        s.query(
            DBChange.date,
            DBChange.source,
            DBChange.version,
            DBChange.changedby,
            DBChangelog.changelog,
        )
        .join(DBChangelog, DBChange.changelog_id == DBChangelog.id)
        .filter(DBChange.source != "debian-keyring")
        .filter(
            or_(
                DBChangelog.changelog.ilike(f"%{search_term}%"),
                DBChange.changedby.ilike(f"%{search_term}%"),
            )
        )
        .order_by(DBChange.seen)
    )

    ret = []
    for c in q:
        ret.append(
            {
                "date": c.date,
                "source": c.source,
                "version": c.version,
                "changedby": c.changedby,
                "changelog": c.changelog,
            }
        )

    s.close()

    return json.dumps(ret)


QueryRegister().register_path("/changelogs", changelogs)


@bottle.route("/v2/changelogs")
def changelogs_v2() -> str:
    """Improved changelogs endpoint with date range & pagination.

    Query parameters:
      - search_term: (optional) substring to match in changelog text or changedby (ILIKE)
      - since: (optional) ISO date/datetime (e.g. 2024-01-01 or 2024-01-01T12:00:00)
      - till: (optional) ISO date/datetime upper bound (inclusive)
      - source: (optional) exact source package name to restrict
      - since_id: (optional) return only rows with id > since_id (id-based polling)
      - limit: (optional) default 50, max 500
      - offset: (optional) default 0

    Returns JSON object with keys: count, limit, offset, has_more, results[].
    """

    bottle.response.content_type = "application/json; charset=UTF-8"

    search_term = bottle.request.query.get("search_term", "").strip()
    source_filter = bottle.request.query.get("source", "").strip()
    since_param = bottle.request.query.get("since", "").strip()
    till_param = bottle.request.query.get("till", "").strip()
    since_id_str = bottle.request.query.get("since_id", "").strip()

    # Pagination params
    try:
        limit = int(bottle.request.query.get("limit", "50"))
    except ValueError:
        limit = 50
    limit = max(1, min(limit, 500))
    try:
        offset = int(bottle.request.query.get("offset", "0"))
    except ValueError:
        offset = 0
    offset = max(0, offset)

    def parse_dt(val: str):
        if not val:
            return None
        # Accept date-only or full isoformat
        try:
            if len(val) == 10:  # YYYY-MM-DD
                return datetime.strptime(val, "%Y-%m-%d")
            return datetime.fromisoformat(val)
        except Exception:
            return None

    since_dt = parse_dt(since_param)
    till_dt = parse_dt(till_param)

    if since_param and not since_dt:
        bottle.response.status = 400
        return json.dumps({"error": "Invalid since parameter (expected ISO date)"})
    if till_param and not till_dt:
        bottle.response.status = 400
        return json.dumps({"error": "Invalid till parameter (expected ISO date)"})

    # Validate id-based filter
    since_id = None
    if since_id_str:
        try:
            since_id = int(since_id_str)
        except Exception:
            bottle.response.status = 400
            return json.dumps(
                {"error": "Invalid since_id parameter (expected integer)"}
            )
        if since_id < 0:
            bottle.response.status = 400
            return json.dumps({"error": "since_id must be >= 0"})

    s = DBConn().session()
    try:
        q = (
            s.query(
                DBChange.change_id,
                DBChange.date,
                DBChange.source,
                DBChange.version,
                DBChange.changedby,
                DBChangelog.changelog,
            )
            .join(DBChangelog, DBChange.changelog_id == DBChangelog.id)
            .filter(DBChange.source != "debian-keyring")
        )

        if search_term:
            like = f"%{search_term}%"
            q = q.filter(
                or_(
                    DBChangelog.changelog.ilike(like),
                    DBChange.changedby.ilike(like),
                )
            )
        if source_filter:
            q = q.filter(DBChange.source == source_filter)
        # Date column may be stored as TEXT; cast to timestamp for comparison
        if since_dt:
            q = q.filter(cast(DBChange.date, TIMESTAMP) >= since_dt)
        if till_dt:
            # Inclusive upper bound
            q = q.filter(cast(DBChange.date, TIMESTAMP) <= till_dt)
        if since_id is not None:
            # Strictly greater than to avoid returning the last seen row again
            q = q.filter(DBChange.change_id > since_id)

        q = q.order_by(DBChange.seen, DBChange.change_id)  # deterministic ordering

        rows = q.offset(offset).limit(limit + 1).all()  # fetch one extra for has_more
        has_more = len(rows) > limit
        rows = rows[:limit]

        results = [
            {
                "id": r.change_id,
                "date": (
                    r.date.isoformat() if hasattr(r.date, "isoformat") else str(r.date)
                ),
                "source": r.source,
                "version": r.version,
                "changedby": r.changedby,
                "changelog": r.changelog,
            }
            for r in rows
        ]

        return json.dumps(
            {
                "count": len(results),
                "limit": limit,
                "offset": offset,
                "has_more": has_more,
                "results": results,
            }
        )
    finally:
        s.close()


QueryRegister().register_path("/v2/changelogs", changelogs_v2)
