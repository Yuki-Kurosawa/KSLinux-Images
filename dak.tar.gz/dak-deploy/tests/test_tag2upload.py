# Copyright (C) 2025, Ansgar <ansgar@debian.org>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

from daklib.tag2upload import (
    _dgit_metadata,
    _parse_tag,
    mangle_version_dep14,
    parse_git_tag_info,
)
from tests.base_test import DakTestCase


class TestParseTag(DakTestCase):
    def test_simple(self) -> None:
        data = (
            b"object 4242424242424242424242424242424242424242\n"
            b"type commit\n"
            b"tag v0.0.1\n"
            b"tagger Ansgar <ansgar@debian.org> 1743510636 +0200\n"
            b"\n"
            b"Some message.\n"
        )
        tag = _parse_tag(data)
        self.assertEqual(tag.object, "4242424242424242424242424242424242424242")
        self.assertEqual(tag.type, "commit")
        self.assertEqual(tag.tag, "v0.0.1")
        self.assertEqual(tag.tagger, "Ansgar <ansgar@debian.org> 1743510636 +0200")
        self.assertEqual(tag.message, "Some message.\n")


class TestDgitMetadata(DakTestCase):
    def test_simple(self) -> None:
        message = (
            "foo release 0.1 for unstable\n"
            "\n"
            "[dgit distro=debian no-split]\n"
            "[dgit please-upload source=foo version=0.1]\n"
        )
        metadata = _dgit_metadata(message)
        self.assertEqual(
            metadata,
            {
                "distro": "debian",
                "no-split": True,
                "source": "foo",
                "version": "0.1",
                "please-upload": True,
            },
        )


class TestParseGitTagInfo(DakTestCase):
    def test_simple(self) -> None:
        value = (
            "tag=4242424242424242424242424242424242424242 "
            "fp=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        )
        info = parse_git_tag_info(value)
        self.assertEqual(info.tag, "4242424242424242424242424242424242424242")
        self.assertEqual(info.fp, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")

    def test_missing_tag(self) -> None:
        value = "fp=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        with self.assertRaises(ValueError):
            parse_git_tag_info(value)


class TestMangleVersionDep14(DakTestCase):
    def test_simple(self) -> None:
        self.assertEqual(mangle_version_dep14("0.1-1"), "0.1-1")
        self.assertEqual(mangle_version_dep14("1:0.1-1"), "1%0.1-1")
        self.assertEqual(mangle_version_dep14("1:0.1-1~1"), "1%0.1-1_1")
        self.assertEqual(mangle_version_dep14("0...1-1"), "0.#.#.1-1")
        self.assertEqual(mangle_version_dep14("0.1-1."), "0.1-1.#")
        self.assertEqual(mangle_version_dep14("0.1-1..lock"), "0.1-1.#.#lock")
