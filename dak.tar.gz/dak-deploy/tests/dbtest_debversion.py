#! /usr/bin/env python3

import unittest
from typing import override

from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.sql import func

import tests.base_test  # noqa: F401
from daklib.dbconn import DebVersion
from tests.db_test import DBDakTestCase


class Base(DeclarativeBase):
    pass


class Version(Base):
    __tablename__ = "version"

    id: Mapped[int] = mapped_column(primary_key=True)
    version: Mapped[str] = mapped_column(DebVersion())

    def __init__(self, version):
        self.version = version

    @override
    def __repr__(self):
        return "<Version('%s')>" % self.version


class DebVersionTestCase(DBDakTestCase):
    """
    The DebVersionTestCase tests both comparison (<=, ==, >, !=), the in_()
    method and aggregate functions (min, max) for the DebVersion type. To
    simplify the test it creates a separate table 'version' which is not used
    by dak itself.
    """

    @override
    def setUp(self):
        super(DebVersionTestCase, self).setUp()
        Version.__table__.create(bind=self.metadata.bind, checkfirst=True)

    def test_debversion(self):
        v = Version("0.5~")
        self.session.add(v)
        v = Version("0.5")
        self.session.add(v)
        v = Version("1.0")
        self.session.add(v)
        q = self.session.query(Version)
        self.assertEqual(3, q.count())
        self.assertEqual(2, q.filter(Version.version <= "0.5").count())
        self.assertEqual(1, q.filter(Version.version == "0.5").count())
        self.assertEqual(2, q.filter(Version.version > "0.5~").count())
        self.assertEqual(1, q.filter(Version.version > "0.5").count())
        self.assertEqual(0, q.filter(Version.version > "1.0").count())
        self.assertEqual(2, q.filter(Version.version != "1.0").count())
        self.assertEqual(2, q.filter(Version.version.in_(["0.5~", "1.0"])).count())
        q = self.session.query(func.min(Version.version))
        self.assertEqual("0.5~", q.scalar())
        q = self.session.query(func.max(Version.version))
        self.assertEqual("1.0", q.scalar())

    @override
    def tearDown(self):
        self.session.rollback()
        Version.__table__.drop(bind=self.metadata.bind)
        super(DebVersionTestCase, self).tearDown()


if __name__ == "__main__":
    unittest.main()
