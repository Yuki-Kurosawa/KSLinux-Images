#! /usr/bin/env python3

import unittest

from base_test import DakTestCase

from daklib.textutils import split_uploaders


class SplitUploadersTestCase(DakTestCase):
    def test_main(self):
        expected = ['"A, B" <a@b.c>', "D E <d@e.f>"]
        uploaders = list(split_uploaders('"A, B" <a@b.c>, D E <d@e.f>'))
        self.assertEqual(expected, uploaders)
        uploaders = list(split_uploaders('"A, B" <a@b.c> , D E <d@e.f>'))
        self.assertEqual(expected, uploaders)
        uploaders = list(split_uploaders('"A, B" <a@b.c>,D E <d@e.f>'))
        self.assertEqual(expected, uploaders)
        uploaders = list(split_uploaders('"A, B" <a@b.c>   ,D E <d@e.f>'))
        self.assertEqual(expected, uploaders)


if __name__ == "__main__":
    unittest.main()
