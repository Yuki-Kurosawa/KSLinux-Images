#! /usr/bin/env python3

from daklib import regexes
from tests.base_test import DakTestCase


class re_single_line_field(DakTestCase):
    _re = regexes.re_single_line_field

    def _assertMatchGroup(self, s: str, groups: tuple[str, ...]) -> None:
        m = self._re.match(s)
        self.assertIsNotNone(m)
        # The explicit check is needed for Mypy.
        if m is not None:
            self.assertEqual(m.groups(), groups)

    def testSimple(self):
        self._assertMatchGroup("Foo: bar", ("Foo", "bar"))

    def testLeadingWhitespace(self):
        self.assertIsNone(self._re.match(" Foo: bar"))

    def testTrailingWhitespace(self):
        self._assertMatchGroup("Foo: bar \n", ("Foo", "bar "))

    def testMiddleWhitespace(self):
        self._assertMatchGroup("Foo:  bar", ("Foo", "bar"))
        self._assertMatchGroup("Foo :  bar", ("Foo", "bar"))
        self._assertMatchGroup("Foo \n:\n  bar", ("Foo", "bar"))
        self._assertMatchGroup("Foo:bar", ("Foo", "bar"))

    def testColons(self):
        self._assertMatchGroup("Foo: :", ("Foo", ":"))
        self._assertMatchGroup("Foo: ::", ("Foo", "::"))
        self._assertMatchGroup(": ::", ("", "::"))
        self._assertMatchGroup("Foo::bar", ("Foo", ":bar"))
        self._assertMatchGroup("Foo: :bar", ("Foo", ":bar"))


class re_parse_lintian(DakTestCase):
    _re = regexes.re_parse_lintian

    def _assertMatchGroupdict(self, s: str, groupdict: dict[str, str]) -> None:
        m = self._re.match(s)
        self.assertIsNotNone(m)
        # The explicit check is needed for Mypy.
        if m is not None:
            self.assertEqual(m.groupdict(), groupdict)

    def testBinary(self):
        self._assertMatchGroupdict(
            "W: pkgname: some-tag path/to/file",
            {
                "level": "W",
                "package": "pkgname",
                "tag": "some-tag",
                "description": "path/to/file",
            },
        )

    def testBinaryNoDescription(self):
        self._assertMatchGroupdict(
            "W: pkgname: some-tag",
            {
                "level": "W",
                "package": "pkgname",
                "tag": "some-tag",
                "description": "",
            },
        )

    def testSource(self):
        self._assertMatchGroupdict(
            "W: pkgname source: some-tag",
            {
                "level": "W",
                "package": "pkgname source",
                "tag": "some-tag",
                "description": "",
            },
        )

    def testSourceNoDescription(self):
        self._assertMatchGroupdict(
            "W: pkgname source: some-tag path/to/file",
            {
                "level": "W",
                "package": "pkgname source",
                "tag": "some-tag",
                "description": "path/to/file",
            },
        )
