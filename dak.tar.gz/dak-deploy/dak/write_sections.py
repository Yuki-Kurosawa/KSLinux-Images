#! /usr/bin/env python3

"""
Writes out a rfc2822-formatted list of sections and their descriptions.

@contact: Debian FTP Master <ftpmaster@debian.org>
@copyright: 2009  Peter Palfrader <peter@palfrader.org>
@copyright: 2020  Joerg Jaspert <joerg@debian.org>
@license: GNU General Public License version 2 or later
"""

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


################################################################################

import sys
from typing import TYPE_CHECKING, NoReturn

from sqlalchemy import sql

from daklib.dbconn import DBConn

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

################################################################################


def write_sections(session: "Session") -> None:
    query = """
    SELECT
      section,
      description,
      longdesc
    FROM section
    ORDER BY section
    """

    for section, description, longdesc in session.execute(sql.text(query)):
        print("Section: {0}".format(section))
        print("Description: {0}".format(description))
        print("Longdesc: {0}".format(longdesc))
        print()


################################################################################


def usage() -> NoReturn:
    print("usage: dak write-sections")
    sys.exit(0)


################################################################################


def main() -> None:
    if len(sys.argv) != 1:
        usage()

    session = DBConn().session()
    write_sections(session)


#########################################################################################


if __name__ == "__main__":
    main()
