#! /usr/bin/env python3

"""
Modify external overrides.

@contact: Debian FTP Master <ftpmaster@debian.org>
@copyright: 2011  Ansgar Burchardt <ansgar@debian.org>
@license: GNU General Public License version 2 or later
"""

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys
from collections.abc import Iterable, Iterator
from typing import NoReturn

import apt_pkg
from sqlalchemy import sql

from daklib.config import Config
from daklib.dbconn import DBConn, ExternalOverride, get_component, get_suite


def usage() -> NoReturn:
    print(
        """Usage: dak external-overrides COMMAND
Modify external overrides.

  -h, --help                    show this help and exit.
  -f, --force                   allow processing of untouchable suites.

Commands can use a long or abbreviated form:

    import SUITE COMPONENT KEY  import external overrides for KEY
    i SUITE COMPONENT KEY       NOTE: This will replace existing overrides.

    copy FROM TO                copy external overrides from suite FROM to TO
                                NOTE: Needs --force for untouchable TO

For the 'import' command, external overrides are read from standard input and
should be given as lines of the form 'PACKAGE KEY VALUE'.
"""
    )
    sys.exit()


#############################################################################


class ExternalOverrideReader:
    """
    Parses an external override file
    """

    def __init__(self, fh: Iterable[str]):
        self.fh = fh
        self.package: str = ""
        self.key: str = ""
        self.value: list[str] = []

    def _flush(self) -> tuple[str, str, str]:
        """
        Return the parsed line that is being built and start parsing a new line
        """
        res = self.package, self.key, "\n".join(self.value)
        self.package = self.key = ""
        self.value = []
        return res

    def __iter__(self) -> Iterator[tuple[str, str, str]]:
        """
        returns a (package, key, value) tuple for every entry in the external
        override file
        """
        for line in self.fh:
            if not line:
                continue
            if line[0] in (" ", "\t"):
                # Continuation line
                self.value.append(line.rstrip())
            else:
                if self.package is not None:
                    yield self._flush()

                # New line
                (self.package, self.key, value) = line.rstrip().split(None, 2)
                self.value = [value]

        if self.package:
            yield self._flush()


#############################################################################


def external_overrides_copy(
    from_suite_name: str, to_suite_name: str, force=False
) -> None:
    session = DBConn().session()

    from_suite = get_suite(from_suite_name, session)
    to_suite = get_suite(to_suite_name, session)

    if from_suite is None:
        print("E: source %s not found." % from_suite_name)
        session.rollback()
        return
    if to_suite is None:
        print("E: target %s not found." % to_suite_name)
        session.rollback()
        return

    if not force and to_suite.untouchable:
        print("E: refusing to touch untouchable suite %s (not forced)." % to_suite_name)
        session.rollback()
        return

    session.query(ExternalOverride).filter_by(suite=to_suite).delete()
    session.execute(
        sql.text(
            """
    INSERT INTO external_overrides (suite, component, package, key, value)
      SELECT :to_suite, component, package, key, value FROM external_overrides WHERE suite = :from_suite
    """
        ),
        {"from_suite": from_suite.suite_id, "to_suite": to_suite.suite_id},
    )

    session.commit()


def external_overrides_import(
    suite_name: str, component_name: str, key: str, file: Iterable[str], force=False
) -> None:
    session = DBConn().session()

    suite = get_suite(suite_name, session)
    assert suite is not None
    component = get_component(component_name, session)
    assert component is not None

    if not force and suite.untouchable:
        print("E: refusing to touch untouchable suite %s (not forced)." % suite_name)
        session.rollback()
        return

    session.query(ExternalOverride).filter_by(
        suite=suite, component=component, key=key
    ).delete()

    for package, key, value in ExternalOverrideReader(file):
        eo = ExternalOverride()
        eo.suite = suite
        eo.component = component
        eo.package = package
        eo.key = key
        eo.value = value
        session.add(eo)

    session.commit()


#############################################################################


def main() -> None:
    cnf = Config()

    Arguments = [
        ("h", "help", "External-Overrides::Options::Help"),
        ("f", "force", "External-Overrides::Options::Force"),
    ]

    args = apt_pkg.parse_commandline(cnf.Cnf, Arguments, sys.argv)  # type: ignore[attr-defined]
    try:
        Options = cnf.subtree("External-Overrides::Options")
    except KeyError:
        Options = {}

    if "Help" in Options:
        usage()

    force = False
    if "Force" in Options and Options["Force"]:
        force = True

    command = args[0]
    if command in ("import", "i"):
        external_overrides_import(args[1], args[2], args[3], sys.stdin, force)
    elif command in ("copy", "c"):
        external_overrides_copy(args[1], args[2], force)
    else:
        print("E: Unknown commands.")


if __name__ == "__main__":
    main()
