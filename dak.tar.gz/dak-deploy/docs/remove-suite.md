This is too complicated. Should have more `ON DELETE CASCADE`...

```sql
select * from build_queue;

begin;
delete from suite_build_queue_copy sbqc using build_queue bq where sbqc.build_queue_id = bq.id and bq.queue_name in (...);
delete from build_queue where queue_name in (...);
```

```sql
select * from policy_queue;

begin;
delete from policy_queue where queue_name in (...);
```

```bash
dak admin suite list | sort

export suite_to_remove=oldoldstable-backports-sloppy

bash -c 'set -e; set -x; archs=$(dak admin s-a list-arch ${suite_to_remove:?}); for arch in source all ${archs}; do dak admin s-a rm ${suite_to_remove} ${arch} || :; done'
psql -c "delete from suite_src_formats where suite = (select id from suite where suite_name = '${suite_to_remove:?}')"
psql -c "delete from version_check where suite = (select id from suite where suite_name = '${suite_to_remove:?}') or reference = (select id from suite where suite_name = '${suite_to_remove:?}')"

# Not needed for *-debug or buildd-*:
bash -c '
  set -e;
  set -x;
  dak admin suite-config set ${suite_to_remove:?} untouchable=false;
  for component in $(dak admin suite-component list-component ${suite_to_remove:?}); do
    for type in deb dsc udeb; do
      dak control-override -s ${suite_to_remove:?} -c ${component} -t ${type} --set < /dev/null;
    done;
  done;
  dak admin suite-config set ${suite_to_remove:?} untouchable=true;
'
bash -c '
  set -e;
  set -x;
  for component in $(dak admin suite-component list-component ${suite_to_remove:?}); do
    dak external-overrides --force import ${suite_to_remove:?} ${component} Tag < /dev/null;
    dak external-overrides --force import ${suite_to_remove:?} ${component} Build-Essential < /dev/null;
  done;
'

dak admin suite rm ${suite_to_remove:?}

```

