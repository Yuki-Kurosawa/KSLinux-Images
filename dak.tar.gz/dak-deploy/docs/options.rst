Standard options
================

::
    -a/--architectures
    -c/--component
    -h/--help 
    -n/--no-action
    -s/--suite
    -V/--version

Exceptions:

- ``dak process-unchecked`` - backward-compatible options with dinstall
- ``dak control-suite`` - ? hysterical raisins and testing compatibility
