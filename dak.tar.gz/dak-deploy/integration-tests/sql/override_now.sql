-- Create alternative 'now()' function to allow shifting the time of the psql
-- database forward. If no shift is set, it just returns the current time.
--
-- Note that this needs a change in the postgresql search_path to work.

CREATE TABLE time_override (
	add_time interval
);

INSERT INTO time_override VALUES ('0'::interval);

CREATE OR REPLACE FUNCTION now()
  RETURNS timestamptz STABLE PARALLEL SAFE AS
$$
    SELECT pg_catalog.now() + (select coalesce(min(add_time), '0'::interval) from time_override);
$$ language sql;
