# SPDX-License-Identifier: GPL-2.0-or-later

import pytest

from .dbconn import Architecture, Section


def test_Architecture___eq__():
    obj = Architecture("arch")

    with pytest.warns(DeprecationWarning):
        assert obj == "arch"
    with pytest.warns(DeprecationWarning):
        assert "arch" == obj


def test_Architecture___ne__():
    obj = Architecture("arch")

    with pytest.warns(DeprecationWarning):
        assert obj != "zzzz"
    with pytest.warns(DeprecationWarning):
        assert "zzzz" != obj


def test_Section___eq__():
    obj = Section("section")

    with pytest.warns(DeprecationWarning):
        assert obj == "section"
    with pytest.warns(DeprecationWarning):
        assert "section" == obj


def test_Section___ne__():
    obj = Section("section")

    with pytest.warns(DeprecationWarning):
        assert obj != "zzzz"
    with pytest.warns(DeprecationWarning):
        assert "zzzz" != obj
